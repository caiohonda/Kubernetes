# Lab Shebang

  - Take me to the [Lab](https://kodekloud.com/topic/lab-shebang/)


  1. Solution is given below
    
     <details>
       
      **`Print Numbers from 31 to 40`**
     </details>

  2. Solution is given below
    
     <details>

      **`Prints {31..40}`**
     </details>

  3. Solution is given below
    
     <details>

     ```
       #!/bin/bash
       for i in {31..40}
       do
               echo $i
       done
     ```
     </details>

  4. Solution is given below
    
     <details>

      ```  
       print_number4.sh
      ```
     </details>

  5. Solution is given below
    
     <details>
       
       ```
       #!/bin/bash
       echo {1..10}
       ```
     </details>