  # Shell Script Project Introduction
   - Take me to [Video Tutorial](https://kodekloud.com/topic/project-introduction/)
  
     ![lseq](../../images/lseq.PNG)
      
  
