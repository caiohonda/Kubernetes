# Demo - E-Commerce Application

  - Take me to [E-Commerce Application Project Demo](https://kodekloud.com/topic/demo-kodekloud-e-commerce-application/)

Demo
- Install git and access the application code at github.
  ```
  $ sudo yum install -y git
  $ sudo git clone https://github.com/kodekloudhub/learning-app-ecommerce.git
  ```
  
#### Take me to [Instructions](https://github.com/kodekloudhub/learning-app-ecommerce/blob/master/README.md)
