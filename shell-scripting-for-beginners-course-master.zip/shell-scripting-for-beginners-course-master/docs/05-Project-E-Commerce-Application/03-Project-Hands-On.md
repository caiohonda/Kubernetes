# Project Hands On

  - Take me to [Practice Test](https://kodekloud.com/topic/lab-project-2/)
  - Take me to [Automation Script](deploy-ecommerce-application.sh)
  
#### Solutions to the practice test

- Run the below command to give execute permissions to the script

  <details>
  
  ```
  $ chmod +x deploy-ecommerce-application.sh
  ```
  </details>
  
- Run the script
  
  <details>
  
  ```
  $ ./deploy-ecommerce-application.sh
  ```
  </details>
 
 
#### Take me to [Practice Test - Solution](https://kodekloud.com/topic/solution-project-ecommerce-application/)
